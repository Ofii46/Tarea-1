﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenid@ a TAIWI");
            const int maxProductos = 100;
            string[,] productos = new string[maxProductos, 5];
            int contador = 0;

            char agregarMas;

            do
            {
                // Se solicitan los datos del producto
                Console.Write("Ingrese el código del producto: ");
                productos[contador, 0] = LeerTexto();

                Console.Write("Ingrese la descripción del producto: ");
                productos[contador, 1] = LeerTexto();

                Console.Write("Ingrese la cantidad: ");
                productos[contador, 2] = LeerNumero().ToString();

                Console.Write("Ingrese el precio por unidad: ");
                productos[contador, 3] = LeerNumero().ToString();

                // Se calcula y almacena el subtotal individual de los productos 
                productos[contador, 4] = CalcularSubtotal(Convert.ToDecimal(productos[contador, 2]), Convert.ToDecimal(productos[contador, 3])).ToString();

                // Se pregunta si desea agregar otro producto
                Console.Write("¿Desea agregar otro producto? (s/n): ");
                agregarMas = Console.ReadKey().KeyChar;
                Console.WriteLine();

                contador++;

            } while (agregarMas == 's' || agregarMas == 'S');

            // Calcular totales
            decimal totalSubtotal = CalcularTotalSubtotal(productos, contador);
            decimal totalImpuesto = CalcularImpuesto(totalSubtotal);
            decimal precioVenta = CalcularPrecioVenta(totalSubtotal, totalImpuesto);

            // Mostrar resultados
            Console.WriteLine("\n--- Resumen de la Compra ---");
            for (int i = 0; i < contador; i++)
            {
                Console.WriteLine($"Producto: {productos[i, 1]} | Cantidad: {productos[i, 2]} | Precio Unidad: {productos[i, 3]} | Subtotal: {productos[i, 4]:F2}");
            }
            Console.WriteLine($"\nTotal de Subtotales: {totalSubtotal:F2}");
            Console.WriteLine($"Impuesto: {totalImpuesto:F2}");
            Console.WriteLine($"Precio de Venta (con impuesto): {precioVenta:F2}");
            Console.WriteLine($"Total a Pagar: {precioVenta:F2}");

            //Finalización
            Console.WriteLine("\n¡Que pase un buen día!");
            Console.WriteLine("\nPresione cualquier tecla para salir...");
            Console.ReadKey();
        }

        // Se valida que los datos de entrada solo contengan letras
        static string LeerTexto()
        {
            string entrada;
            while (true)
            {
                entrada = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(entrada) && SoloLetras(entrada))
                    break;
                Console.WriteLine("Entrada inválida. Por favor, ingrese solo letras.");
            }
            return entrada;
        }

        // Se valida que los datos de entrada solo sean numéricos
        static decimal LeerNumero()
        {
            decimal numero;
            while (true)
            {
                if (decimal.TryParse(Console.ReadLine(), out numero) && numero >= 0)
                    break;
                Console.WriteLine("Entrada inválida. Por favor, ingrese solo números.");
            }
            return numero;
        }

        // Se verifica que las cadenas contengan solo letras
        static bool SoloLetras(string texto)
        {
            foreach (char c in texto)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                    return false;
            }
            return true;
        }

        static decimal CalcularSubtotal(decimal cantidad, decimal precioUnidad)
        {
            return cantidad * precioUnidad;
        }

        static decimal CalcularTotalSubtotal(string[,] productos, int contador)
        {
            decimal total = 0;
            for (int i = 0; i < contador; i++)
            {
                total += Convert.ToDecimal(productos[i, 4]); // Suma la columna de todos los subtotales
            }
            return total;
        }

        static decimal CalcularImpuesto(decimal subtotal)
        {
            decimal impuesto;
            if (subtotal <= 1000)
            {
                impuesto = subtotal * 0.08m;
            }
            else if (subtotal > 1000 && subtotal < 5000)
            {
                impuesto = subtotal * 0.10m;
            }
            else
            {
                impuesto = subtotal * 0.13m;
            }
            return impuesto;
        }

        static decimal CalcularPrecioVenta(decimal subtotal, decimal impuesto)
        {
            return subtotal + impuesto;
        }

    }
}